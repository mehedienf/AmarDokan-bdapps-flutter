<?php

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/subscriber_store.php';

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(array(
        'success' => false,
        'statusCode' => 'METHOD_NOT_ALLOWED',
        'message' => 'Only POST requests are allowed'
    ));
    exit;
}

$user_otp = isset($_POST['Otp'])
    ? trim($_POST['Otp'])
    : (isset($_POST['otp']) ? trim($_POST['otp']) : '');
$referenceNo = isset($_POST['referenceNo'])
    ? trim($_POST['referenceNo'])
    : (isset($_POST['reference_no']) ? trim($_POST['reference_no']) : '');
$rawMobile = $_POST['user_mobile'] ?? $_POST['mobile'] ?? $_POST['phone'] ?? '';

if (empty($user_otp) || empty($referenceNo)) {
    echo json_encode(array(
        'statusCode' => 'FAILED',
        'message' => 'Missing OTP or referenceNo',
        'statusDetail' => 'OTP and reference number are required'
    ));
    exit;
}

// Resolve plain phone number from POST or from stored pending OTP referenceNo
$plainPhone = normalizeBdPhone((string)$rawMobile);
if ($plainPhone === null) {
    $plainPhone = getPhoneByReference($referenceNo);
}

$requestData = array(
    "applicationId" => "APP_140650",
    "password" => "1a9508a7e7a354e88654a615322589e6",
    "referenceNo" => $referenceNo,
    "otp" => $user_otp
);

$requestJson = json_encode($requestData);

$url = "https://developer.bdapps.com/subscription/otp/verify";
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $requestJson);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
    "Content-Type: application/json",
    "Content-Length: " . strlen($requestJson)
));
curl_setopt($ch, CURLOPT_TIMEOUT, 15);

$responseJson = curl_exec($ch);

if ($responseJson === false) {
    $error = curl_error($ch);
    curl_close($ch);
    echo json_encode(array(
        'statusCode' => 'FAILED',
        'message' => 'Connection error: ' . $error,
        'statusDetail' => 'Unable to connect to BDApps server'
    ));
    exit;
}

curl_close($ch);

$response = json_decode($responseJson, true);

if ($response === null) {
    echo json_encode(array(
        'statusCode' => 'FAILED',
        'message' => 'Invalid API response',
        'statusDetail' => 'Failed to parse BDApps response',
        'rawResponse' => $responseJson
    ));
    exit;
}

$statusCode = isset($response['statusCode']) ? (string) $response['statusCode'] : 'FAILED';
$statusDetail = isset($response['statusDetail']) ? (string) $response['statusDetail'] : '';
$subscriptionStatus = isset($response['subscriptionStatus'])
    ? (string) $response['subscriptionStatus']
    : '';
$maskedSubscriberId = isset($response['subscriberId'])
    ? trim((string) $response['subscriberId'])
    : '';

$success = strtoupper($statusCode) === 'S1000' ||
    strtolower($statusDetail) === 'success' ||
    strtoupper($subscriptionStatus) === 'REGISTERED';

// Store the plainPhone -> maskedSubscriberId mapping on the server
if ($plainPhone !== null && $maskedSubscriberId !== '' && ($success || strtoupper($subscriptionStatus) === 'REGISTERED')) {
    saveSubscriberMapping(
        $plainPhone,
        $maskedSubscriberId,
        $referenceNo,
        $subscriptionStatus !== '' ? strtoupper($subscriptionStatus) : 'REGISTERED'
    );
}

echo json_encode(array(
    'success' => $success,
    'statusCode' => $statusCode,
    'message' => $success ? 'Subscription successful' : $statusDetail,
    'statusDetail' => $statusDetail,
    'subscriptionStatus' => $subscriptionStatus,
    'subscriberId' => $maskedSubscriberId,
    'plainPhone' => $plainPhone,
    'version' => isset($response['version']) ? $response['version'] : ''
));

?>

<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json; charset=utf-8");

require_once __DIR__ . '/subscriber_store.php';

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

function queryBdappsStatus(string $subscriberId): array {
    $requestData = [
        'version' => '1.0',
        'applicationId' => 'APP_140650',
        'password' => '1a9508a7e7a354e88654a615322589e6',
        'subscriberId' => $subscriberId,
    ];

    $requestJson = json_encode($requestData);

    $url = 'https://developer.bdapps.com/subscription/getStatus';
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $requestJson);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'Content-Length: ' . strlen($requestJson),
    ]);

    $responseJson = curl_exec($ch);
    $curlError = curl_error($ch);
    curl_close($ch);

    if ($responseJson === false) {
        return ['ok' => false, 'error' => 'cURL failed', 'details' => $curlError];
    }

    $response = json_decode($responseJson, true);
    if (!is_array($response)) {
        return ['ok' => false, 'error' => 'Invalid response'];
    }

    return ['ok' => true, 'data' => $response];
}

$rawMobile = $_POST['user_mobile'] ?? '';
$digits = normalizeBdPhone((string)$rawMobile);

// Validate Bangladesh mobile number
if ($digits === null) {
    echo json_encode([
        'error' => 'Invalid mobile number format',
        'providedNumber' => $rawMobile
    ]);
    exit;
}

$plainSubscriberId = 'tel:88' . $digits;
$storedMaskedId = getMaskedSubscriberId($digits);

// Use stored masked subscriberId if available, otherwise plain subscriberId
$subscriberId = $storedMaskedId ?? $plainSubscriberId;

$result = queryBdappsStatus($subscriberId);
if (!$result['ok']) {
    echo json_encode($result);
    exit;
}

$response = $result['data'];
$status = strtoupper(trim($response['subscriptionStatus'] ?? ''));

// If masked lookup did not return REGISTERED, fallback to plain subscriberId check
if ($status !== 'REGISTERED' && $storedMaskedId !== null && $storedMaskedId !== $plainSubscriberId) {
    $fallbackResult = queryBdappsStatus($plainSubscriberId);
    if ($fallbackResult['ok']) {
        $fbResponse = $fallbackResult['data'];
        $fbStatus = strtoupper(trim($fbResponse['subscriptionStatus'] ?? ''));
        if ($fbStatus === 'REGISTERED') {
            $response = $fbResponse;
            $status = $fbStatus;
            $subscriberId = $plainSubscriberId;
        }
    }
}

$isSubscribed = ($status === 'REGISTERED');

if ($status !== '') {
    updateSubscriberStatus($digits, $status);
}

echo json_encode([
    'subscriptionStatus' => $status,
    'isSubscribed' => $isSubscribed,
    'statusCode' => $response['statusCode'] ?? null,
    'statusDetail' => $response['statusDetail'] ?? null,
    'version' => $response['version'] ?? null,
    'subscriberId' => $subscriberId,
    'plainPhone' => $digits,
    'matchedMaskedId' => $storedMaskedId !== null
]);
?>

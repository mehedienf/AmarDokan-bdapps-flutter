<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json; charset=utf-8");

ini_set('display_errors', '0');
error_reporting(E_ALL & ~E_DEPRECATED & ~E_USER_DEPRECATED);

require_once __DIR__ . '/subscriber_store.php';

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

function callBdapps(string $url, array $requestData): array {
    $requestJson = json_encode($requestData);
    if ($requestJson === false) {
        return ['ok' => false, 'error' => 'Failed to encode request'];
    }

    $ch = curl_init();
    if ($ch === false) {
        return ['ok' => false, 'error' => 'Unable to initialize cURL'];
    }

    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $requestJson);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        "Content-Type: application/json",
        "Content-Length: " . strlen($requestJson)
    ));
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);

    $responseJson = curl_exec($ch);
    $curlError = curl_error($ch);
    curl_close($ch);

    if ($responseJson === false) {
        return ['ok' => false, 'error' => "cURL failed: $curlError"];
    }

    $response = json_decode($responseJson, true);
    if (!is_array($response)) {
        return ['ok' => false, 'error' => 'Invalid response', 'raw' => $responseJson];
    }

    return ['ok' => true, 'data' => $response, 'raw' => $responseJson];
}

$rawMobile = trim($_POST['user_mobile'] ?? $_POST['subscriberId'] ?? '');
$explicitSubscriberId = trim($_POST['masked_subscriber_id'] ?? $_POST['subscriberId'] ?? '');

if ($rawMobile === '' && $explicitSubscriberId === '') {
    echo json_encode(['success' => false, 'error' => 'Mobile number required']);
    exit;
}

$plainPhone = normalizeBdPhone($rawMobile);
$storedMaskedId = null;

if ($plainPhone !== null) {
    // Match the plain mobile number with the stored masked subscriberId on our server
    $storedMaskedId = getMaskedSubscriberId($plainPhone);
    if ($storedMaskedId === null && $explicitSubscriberId !== '' && normalizeBdPhone($explicitSubscriberId) === null) {
        $storedMaskedId = ensureTelPrefix($explicitSubscriberId);
    }
    $subscriberId = $storedMaskedId ?? ('tel:88' . $plainPhone);
} else {
    // Caller passed a masked subscriberId directly
    $subscriberId = ensureTelPrefix($rawMobile !== '' ? $rawMobile : $explicitSubscriberId);
    $plainPhone = getPhoneByMaskedSubscriberId($subscriberId);
}

$appId = 'APP_140650';
$password = '1a9508a7e7a354e88654a615322589e6';

$requestData = array(
    'applicationId' => $appId,
    'password' => $password,
    'subscriberId' => $subscriberId,
    'version' => '1.0',
    'action' => '0',
);

$result = callBdapps('https://developer.bdapps.com/subscription/send', $requestData);

if (!$result['ok']) {
    echo json_encode([
        'success' => false,
        'error' => $result['error'],
        'subscriberId' => $subscriberId,
        'plainPhone' => $plainPhone,
        'action' => '0',
    ]);
    exit;
}

$response = $result['data'];
$statusCode = strtoupper((string)($response['statusCode'] ?? ''));
$subscriptionStatus = $response['subscriptionStatus'] ?? 'UNKNOWN';

$success =
    $statusCode === 'S1000' ||
    strtoupper((string)$subscriptionStatus) === 'UNREGISTERED';

// Fallback: if masked subscriberId failed and we have a plain phone, try plain subscriberId once
if (!$success && $plainPhone !== null && $storedMaskedId !== null) {
    $fallbackSubscriberId = 'tel:88' . $plainPhone;
    if ($fallbackSubscriberId !== $subscriberId) {
        $requestData['subscriberId'] = $fallbackSubscriberId;
        $fallbackResult = callBdapps('https://developer.bdapps.com/subscription/send', $requestData);
        if ($fallbackResult['ok']) {
            $fbResponse = $fallbackResult['data'];
            $fbStatusCode = strtoupper((string)($fbResponse['statusCode'] ?? ''));
            $fbSubStatus = $fbResponse['subscriptionStatus'] ?? 'UNKNOWN';
            if ($fbStatusCode === 'S1000' || strtoupper((string)$fbSubStatus) === 'UNREGISTERED') {
                $result = $fallbackResult;
                $response = $fbResponse;
                $statusCode = $fbStatusCode;
                $subscriptionStatus = $fbSubStatus;
                $subscriberId = $fallbackSubscriberId;
                $success = true;
            }
        }
    }
}

if ($success && $plainPhone !== null) {
    updateSubscriberStatus($plainPhone, 'UNREGISTERED');
}

echo json_encode([
    'success' => $success,
    'subscriberId' => $subscriberId,
    'plainPhone' => $plainPhone,
    'matchedMaskedId' => $storedMaskedId !== null,
    'action' => '0',
    'version' => '1.0',
    'statusCode' => $response['statusCode'] ?? null,
    'statusDetail' => $response['statusDetail'] ?? null,
    'subscriptionStatus' => $subscriptionStatus,
    'rawResponse' => $result['raw'] ?? null,
]);

?>

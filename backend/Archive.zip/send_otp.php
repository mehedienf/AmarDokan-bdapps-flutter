<?php

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/subscriber_store.php';

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode([
        'success' => false,
        'message' => 'Only POST requests are allowed',
        'referenceNo' => null
    ]);
    exit;
}

$rawMobile = $_POST['user_mobile'] ?? '';
$digits = normalizeBdPhone($rawMobile);

// Validate Bangladesh mobile number
if ($digits === null) {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid mobile number format',
        'referenceNo' => null
    ]);
    exit;
}

// bdapps subscriberId format
$user_mobile = 'tel:88' . $digits;

// Request data
$requestData = [
    'applicationId' => 'APP_140650',
    'password' => '1a9508a7e7a354e88654a615322589e6',
    'subscriberId' => $user_mobile,
    'applicationHash' => 'Amar Dokan',
    'applicationMetaData' => [
        'client' => 'MOBILEAPP',
        'device' => 'Web browser',
        'os' => 'Web',
        'appCode' => 'AmarDokan'
    ]
];

$requestJson = json_encode($requestData);

$url = 'https://developer.bdapps.com/subscription/otp/request';
$ch = curl_init();

curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $requestJson);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_TIMEOUT, 30);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json',
    'Content-Length: ' . strlen($requestJson)
]);

$responseJson = curl_exec($ch);

if ($responseJson === false) {
    echo json_encode([
        'success' => false,
        'message' => 'cURL error: ' . curl_error($ch),
        'referenceNo' => null
    ]);
    curl_close($ch);
    exit;
}

$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

// Check if response looks like HTML (error page)
if (stripos($responseJson, '<html') !== false || stripos($responseJson, '<!DOCTYPE') !== false) {
    echo json_encode([
        'success' => false,
        'message' => 'Server returned HTML instead of JSON. HTTP code: ' . $httpCode,
        'referenceNo' => null,
        'httpCode' => $httpCode
    ]);
    exit;
}

$response = json_decode($responseJson, true);

if (!is_array($response)) {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid JSON in response',
        'raw' => substr($responseJson, 0, 500),
        'referenceNo' => null,
        'httpCode' => $httpCode
    ]);
    exit;
}

$referenceNo = isset($response['referenceNo']) ? trim((string)$response['referenceNo']) : '';
$statusCode = isset($response['statusCode']) ? (string)$response['statusCode'] : '';
$statusDetail = isset($response['statusDetail']) ? (string)$response['statusDetail'] : '';
$version = isset($response['version']) ? (string)$response['version'] : '';
$returnedSubscriberId = isset($response['subscriberId']) ? trim((string)$response['subscriberId']) : '';

if ($returnedSubscriberId !== '' && $returnedSubscriberId !== $user_mobile) {
    saveSubscriberMapping($digits, $returnedSubscriberId, $referenceNo, 'REGISTERED');
}

if ($referenceNo !== '') {
    // Store referenceNo -> plain mobile number so verify_otp.php can match it
    savePendingOtpReference($referenceNo, $digits);

    echo json_encode([
        'success' => true,
        'referenceNo' => $referenceNo,
        'statusCode' => $statusCode,
        'statusDetail' => $statusDetail,
        'version' => $version
    ]);
    exit;
}

echo json_encode([
    'success' => false,
    'message' => $statusDetail !== '' ? $statusDetail : 'OTP reference not returned',
    'referenceNo' => null,
    'statusCode' => $statusCode,
    'statusDetail' => $statusDetail,
    'version' => $version,
    'subscriberId' => $user_mobile
]);
?>

?>
<?php

/**
 * Helper functions to store and match plain mobile numbers (018xxxxxxxx)
 * with BDApps masked subscriberIds (e.g. tel:B%3C...).
 */

define('SUBSCRIBERS_DB_FILE', __DIR__ . '/subscribers.json');

/**
 * Normalize a Bangladesh mobile number to 11 digits (01XXXXXXXXX).
 * Returns null if the number is not a valid BD mobile number.
 */
function normalizeBdPhone(string $rawMobile): ?string {
    $digits = preg_replace('/\D+/', '', $rawMobile);

    if (strpos($digits, '880') === 0 && strlen($digits) === 13) {
        $digits = '0' . substr($digits, 3);
    } elseif (strpos($digits, '88') === 0 && strlen($digits) === 12) {
        $digits = '0' . substr($digits, 2);
    } elseif (strlen($digits) === 10 && $digits[0] === '1') {
        $digits = '0' . $digits;
    }

    if (!preg_match('/^01[3-9][0-9]{8}$/', $digits)) {
        return null;
    }

    return $digits;
}

/**
 * Ensure the subscriberId starts with 'tel:'.
 */
function ensureTelPrefix(string $subscriberId): string {
    $subscriberId = trim($subscriberId);
    if ($subscriberId === '') {
        return '';
    }
    if (stripos($subscriberId, 'tel:') !== 0) {
        return 'tel:' . $subscriberId;
    }
    return $subscriberId;
}

/**
 * Read and update subscribers.json atomically using file locking.
 */
function withSubscriberStore(callable $callback) {
    $filePath = SUBSCRIBERS_DB_FILE;
    $fp = @fopen($filePath, 'c+');
    if ($fp === false) {
        return null;
    }

    if (!flock($fp, LOCK_EX)) {
        fclose($fp);
        return null;
    }

    $contents = stream_get_contents($fp);
    $store = is_string($contents) && trim($contents) !== ''
        ? json_decode($contents, true)
        : null;

    if (!is_array($store)) {
        $store = array(
            'subscribers' => array(),
            'pending_otp' => array(),
        );
    }
    if (!isset($store['subscribers']) || !is_array($store['subscribers'])) {
        $store['subscribers'] = array();
    }
    if (!isset($store['pending_otp']) || !is_array($store['pending_otp'])) {
        $store['pending_otp'] = array();
    }

    // Clean up pending OTP references older than 24 hours
    $now = time();
    foreach ($store['pending_otp'] as $ref => $info) {
        $ts = isset($info['timestamp']) ? (int)$info['timestamp'] : 0;
        if ($ts > 0 && ($now - $ts) > 86400) {
            unset($store['pending_otp'][$ref]);
        }
    }

    $modified = false;
    $result = $callback($store, $modified);

    if ($modified) {
        $encoded = json_encode($store, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
        if ($encoded !== false) {
            ftruncate($fp, 0);
            rewind($fp);
            fwrite($fp, $encoded);
            fflush($fp);
        }
    }

    flock($fp, LOCK_UN);
    fclose($fp);

    return $result;
}

/**
 * Save a temporary mapping from OTP referenceNo to plain phone number
 * when send_otp.php succeeds.
 */
function savePendingOtpReference(string $referenceNo, string $plainPhone): void {
    $referenceNo = trim($referenceNo);
    $plainPhone = normalizeBdPhone($plainPhone) ?? '';
    if ($referenceNo === '' || $plainPhone === '') {
        return;
    }

    withSubscriberStore(function (array &$store, bool &$modified) use ($referenceNo, $plainPhone) {
        $store['pending_otp'][$referenceNo] = array(
            'phone' => $plainPhone,
            'plainSubscriberId' => 'tel:88' . $plainPhone,
            'timestamp' => time(),
            'createdAt' => date('c'),
        );
        $modified = true;
    });
}

/**
 * Retrieve the plain phone number associated with an OTP referenceNo.
 */
function getPhoneByReference(string $referenceNo): ?string {
    $referenceNo = trim($referenceNo);
    if ($referenceNo === '') {
        return null;
    }

    return withSubscriberStore(function (array &$store, bool &$modified) use ($referenceNo) {
        if (isset($store['pending_otp'][$referenceNo]['phone'])) {
            return (string)$store['pending_otp'][$referenceNo]['phone'];
        }
        foreach ($store['subscribers'] as $phone => $record) {
            if (isset($record['referenceNo']) && $record['referenceNo'] === $referenceNo) {
                return (string)$phone;
            }
        }
        return null;
    });
}

/**
 * Save or update the plain phone -> masked subscriberId mapping.
 */
function saveSubscriberMapping(
    string $plainPhone,
    string $maskedSubscriberId,
    string $referenceNo = '',
    string $subscriptionStatus = 'REGISTERED'
): void {
    $normalizedPhone = normalizeBdPhone($plainPhone);
    $formattedMaskedId = ensureTelPrefix($maskedSubscriberId);

    if ($normalizedPhone === null || $formattedMaskedId === '') {
        return;
    }

    withSubscriberStore(function (array &$store, bool &$modified) use (
        $normalizedPhone,
        $formattedMaskedId,
        $referenceNo,
        $subscriptionStatus
    ) {
        $existing = isset($store['subscribers'][$normalizedPhone]) && is_array($store['subscribers'][$normalizedPhone])
            ? $store['subscribers'][$normalizedPhone]
            : array();

        $store['subscribers'][$normalizedPhone] = array(
            'phone' => $normalizedPhone,
            'plainSubscriberId' => 'tel:88' . $normalizedPhone,
            'maskedSubscriberId' => $formattedMaskedId,
            'referenceNo' => $referenceNo !== '' ? $referenceNo : ($existing['referenceNo'] ?? ''),
            'subscriptionStatus' => $subscriptionStatus,
            'createdAt' => $existing['createdAt'] ?? date('c'),
            'updatedAt' => date('c'),
        );

        if ($referenceNo !== '' && isset($store['pending_otp'][$referenceNo])) {
            unset($store['pending_otp'][$referenceNo]);
        }

        $modified = true;
    });
}

/**
 * Look up the stored masked subscriberId for a plain phone number.
 */
function getMaskedSubscriberId(string $plainPhone): ?string {
    $normalizedPhone = normalizeBdPhone($plainPhone);
    if ($normalizedPhone === null) {
        return null;
    }

    return withSubscriberStore(function (array &$store, bool &$modified) use ($normalizedPhone) {
        if (!isset($store['subscribers'][$normalizedPhone])) {
            return null;
        }
        $record = $store['subscribers'][$normalizedPhone];
        $masked = isset($record['maskedSubscriberId']) ? trim((string)$record['maskedSubscriberId']) : '';
        return $masked !== '' ? ensureTelPrefix($masked) : null;
    });
}

/**
 * Find plain phone number by masked subscriberId (reverse lookup).
 */
function getPhoneByMaskedSubscriberId(string $maskedSubscriberId): ?string {
    $formattedMaskedId = ensureTelPrefix($maskedSubscriberId);
    if ($formattedMaskedId === '') {
        return null;
    }

    return withSubscriberStore(function (array &$store, bool &$modified) use ($formattedMaskedId) {
        foreach ($store['subscribers'] as $phone => $record) {
            $storedMasked = isset($record['maskedSubscriberId'])
                ? ensureTelPrefix((string)$record['maskedSubscriberId'])
                : '';
            if ($storedMasked !== '' && $storedMasked === $formattedMaskedId) {
                return (string)$phone;
            }
        }
        return null;
    });
}

/**
 * Update the subscriptionStatus for an existing phone record.
 */
function updateSubscriberStatus(string $plainPhone, string $status): void {
    $normalizedPhone = normalizeBdPhone($plainPhone);
    if ($normalizedPhone === null) {
        return;
    }

    withSubscriberStore(function (array &$store, bool &$modified) use ($normalizedPhone, $status) {
        if (isset($store['subscribers'][$normalizedPhone]) && is_array($store['subscribers'][$normalizedPhone])) {
            $store['subscribers'][$normalizedPhone]['subscriptionStatus'] = $status;
            $store['subscribers'][$normalizedPhone]['updatedAt'] = date('c');
            $modified = true;
        }
    });
}
?>

